-- MySQL dump 10.14  Distrib 5.5.47-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: omeka_db
-- ------------------------------------------------------
-- Server version	5.5.47-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `omeka_collections`
--

DROP TABLE IF EXISTS `omeka_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_collections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `public` tinyint(4) NOT NULL,
  `featured` tinyint(4) NOT NULL,
  `added` timestamp NOT NULL DEFAULT '2000-01-01 05:00:00',
  `modified` timestamp NOT NULL DEFAULT '2000-01-01 05:00:00',
  `owner_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `public` (`public`),
  KEY `featured` (`featured`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_collections`
--

LOCK TABLES `omeka_collections` WRITE;
/*!40000 ALTER TABLE `omeka_collections` DISABLE KEYS */;
INSERT INTO `omeka_collections` VALUES (1,0,0,'2016-06-14 19:57:33','2016-06-14 19:57:33',1);
/*!40000 ALTER TABLE `omeka_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_comments`
--

DROP TABLE IF EXISTS `omeka_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(10) unsigned NOT NULL,
  `record_type` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `path` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `author_email` tinytext COLLATE utf8_unicode_ci,
  `author_url` tinytext COLLATE utf8_unicode_ci,
  `author_name` tinytext COLLATE utf8_unicode_ci,
  `ip` tinytext COLLATE utf8_unicode_ci,
  `user_agent` tinytext COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `flagged` tinyint(1) NOT NULL DEFAULT '0',
  `is_spam` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `record_id` (`record_id`,`user_id`,`parent_comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_comments`
--

LOCK TABLES `omeka_comments` WRITE;
/*!40000 ALTER TABLE `omeka_comments` DISABLE KEYS */;
INSERT INTO `omeka_comments` VALUES (1,1,'Item','/items/show/1','2016-07-12 00:07:02','<p>Test comment</p>','cs4dh@faokryn.com','','Super User','10.0.2.2','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36',1,NULL,1,0,0);
/*!40000 ALTER TABLE `omeka_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_corrections_corrections`
--

DROP TABLE IF EXISTS `omeka_corrections_corrections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_corrections_corrections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reviewed` timestamp NULL DEFAULT NULL,
  `item_id` int(10) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `status` tinytext COLLATE utf8_unicode_ci,
  `owner_id` int(10) DEFAULT NULL,
  `email` tinytext COLLATE utf8_unicode_ci,
  `may_contact` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_corrections_corrections`
--

LOCK TABLES `omeka_corrections_corrections` WRITE;
/*!40000 ALTER TABLE `omeka_corrections_corrections` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_corrections_corrections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_element_sets`
--

DROP TABLE IF EXISTS `omeka_element_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_element_sets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `record_type` (`record_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_element_sets`
--

LOCK TABLES `omeka_element_sets` WRITE;
/*!40000 ALTER TABLE `omeka_element_sets` DISABLE KEYS */;
INSERT INTO `omeka_element_sets` VALUES (1,NULL,'Dublin Core','The Dublin Core metadata element set is common to all Omeka records, including items, files, and collections. For more information see, http://dublincore.org/documents/dces/.'),(3,'Item','Item Type Metadata','The item type metadata element set, consisting of all item type elements bundled with Omeka and all item type elements created by an administrator.');
/*!40000 ALTER TABLE `omeka_element_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_element_texts`
--

DROP TABLE IF EXISTS `omeka_element_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_element_texts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(10) unsigned NOT NULL,
  `record_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `element_id` int(10) unsigned NOT NULL,
  `html` tinyint(4) NOT NULL,
  `text` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `record_type_record_id` (`record_type`,`record_id`),
  KEY `element_id` (`element_id`),
  KEY `text` (`text`(20))
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_element_texts`
--

LOCK TABLES `omeka_element_texts` WRITE;
/*!40000 ALTER TABLE `omeka_element_texts` DISABLE KEYS */;
INSERT INTO `omeka_element_texts` VALUES (1,1,'Collection',50,0,'Jewish Perspective on the Boxer Rebellion'),(2,1,'Collection',41,0,'Journal entries from a Jewish soldier during the Boxer Rebellion with modern media of the locations metioned'),(3,1,'Item',50,0,'Zhmerinka'),(4,1,'Item',40,0,'1899-07-07'),(5,1,'Item',1,0,'\"We worked all day carrying the army gear, which was needed for the journey, to the railroad depot. At 11 A.M. we ate our meal and before we could even finish eating the bugle sounded assembly. We threw down the mess kits with the kasha (5) and the borscht and ran to put on full battle gear, and then we fell into formation. We looked at our barracks, which appeared now, empty and deserted. A feeling of terror came upon us.\r\n\r\nMany people were gathered in the parade grounds. Jews, Christians. Civilians and military people - all came to say good-bye and to observe the departure ceremony.\r\n\r\nThen came the regiment commander with the brigade General Katrievitch. The general greeted us first, then came the military chaplain. He conducted a prayer service: he offered a prayer for the welfare of the Czar and his heir and then wished us success and good luck on our journey.\r\n\r\nThe rabbi came to see us, the Jewish soldiers. He brought with him a scroll of the Torah (6) and asked the general if he could conduct a service for us. Permission was granted. The rabbi stood near a table, put on a talis (7) and recited a few psalms. (honoten y\'shuo. a mi sheberach) and that was the end our service. Then Schwartzman, the contractor, brought wine and said he wanted to drink to the general\'s health. And the general gave permission.\r\n\r\nFour silver goblets were brought and filled with wine. The first goblet was given to the general. The second - to our regiment commander. The third - to the commander of the 10th regiment and the fourth - to Schwartsman. The general drank to the health of His Imperial Majesty, the Czar and to the health of Her Imperial Majesty, the Czarina; then he drank to the health of the inhabitants of the town of Zhmerinke, which he said gave him so much joy. We yelled: \"\"Hurrah! Hurrah!” the band played and they all drank the first toast. Then Schwartzman drank to the health of their Excellences. The commanders of the 9th and the 10th regiments and to the health of all the riflemen and we yelled: \"\"Hurrah! Hurrah\"\"\'\r\n\r\nThen vodka was set up for the soldiers and a table of cold cuts for the whole regiment- and it made no difference whether Jew or Christian: all drank. The general was pleased with the local Jews and he thanked them for their help.\r\n\r\nA photographer came and took a picture of the whole regiment so that we would have a reminder of this day. Then Schwartzman said to us: “Even though we are Jews, we are Russian subjects and we should exert every effort to fight the enemy and fight with all we\'ve got. May God give you strength and endurance to overcome everything and to succeed wherever you go.”\r\n\r\nThe band was still playing but things quieted down a little. More vodka was brought in and we drank some more and from regular drinking glasses - we were having a good time in the midst of all our troubles.\r\n\r\nThen all this ended - the regimental commander shouted: \"\"Shoulder arms! Forward march! \"\"The band played a lively, brisk march and we started marching. \r\n\r\nThe officers Started saying good-bye to their wives and children. They kissed and cried and were off to the railroad station singing Russian songs as we marched.\r\n\r\nThe whole town was following us - it felt like a funeral of the living: one was laughing, one was crying and another was sighing as he was looking at these young men going off to war.\r\n\r\nAs we arrived at the railroad station - it was packed full of people. Parents, brothers, sisters and friends were wailing - all wanted to say good-bye and to wish us a pleasant journey. The screaming and the hollering is loud enough to reach   the heavens.	 Just then we heard the first bell. The officers were shouting \"\"into the (train) cars!\"\" The good-byes were said, the tears were pouring and the reminders were heard: “For God\'s sake, don\'t forget to write letters!” We got into the cars - twenty soldiers to a car and as we sat down in our seats we heard the second and third bells.\r\n\r\nThe band was playing a march and all the people were waving good- bye with their hats or with their kerchiefs. The photographer took another picture.  The engineer blew the whistle and the train started moving.  Feeling sad and brokenhearted the soldiers began singing Russian songs. The singing was worse (sadder) than the crying. Some people were still waving good- bye but the train started moving and it was difficult to see now.  We could still hear shouts of “Farewell! Farewell!\"\" Some soldiers were crying and the tears were flowing like water when they heard the shouts of farewell and each one thought to himself: \"\"Who knows whether we will ever see each other again, whether we will ever return and see Zhmerinke.\"\"\r\n\r\nWe soldiers were sitting in our train cars like chickens before the slaughter. We were in a gloomy mood like after N’ilah (9) and all kinds of thoughts ran through our minds: we are going to war we will have to shoot to stab to suffer hardships by the pound - and you begin to rue the day of your birth.\r\n\r\nAs the train started to move, some soldiers were walking around and yelling: \"\"Come. Brothers let\'s drink some vodka and have a bite to eat because if you’ll start brooding you’ll go crazy!\"\" Some men were convinced of this truth and they had so much to drink that they didn\'t know any more what trouble they were in.\r\n\r\nOne soldier got the idea to play cards. So he gathered together a company of men and they played cards. Each one thought that he will win - but one can lose much easier than one can win. Some of the men lost so badly that they were left without a penny - and if one of them ended up owing you money, there was nothing you could do about it unless you were prepared to kill him.\"'),(6,2,'Item',50,0,'Vinitse'),(7,2,'Item',40,0,'1899-07-07'),(8,2,'Item',1,0,'\"Meanwhile, the train stopped at the railroad station at Vinitse. We were received nicely. The local band was playing and the sign was given to get out of the train cars and then we just stood around for twenty minutes. Many people came running, Jews and Gentiles, and everybody was asking: \"\"Where are you going?\"\" We told everybody in secret: \"\"We are off to war.\"\" One person sighed upon hearing this. Another groaned, a third rolled his eyes and got weepy. We were already sick and tired of the public\'s reaction to our going to war. The first bell rang, the signal was given to get back into the train cars, our \"\"horse\"\" gave a whistle and the train was moving off. All the people were bowing to us taking off their hats and we were yelling: \"\"Hurrah! Hurrah!\"\" The shouting almost broke the train car apart.\r\n\r\nNow night was falling. We started looking around for a place to sleep. But woe! There was nothing to sleep on but the slatted coach seats and even these would not accommodate everybody. Just imagine! Twenty men to a car and there was nothing to put under you for bedding. What was a soldier to do? He had a soldier\'s coat, a \"\"shinel\"\" (10) - that\'s all. As he lay down to sleep the soldier put his shinel under him. And he also covered himself with his shinel and put it under his head as well. So, it would seem that the soldier slept well! When we got up in the morning there was not a bone in our bodies that didn\'t ache because of these \"\"soft\"\" beds that we were sleeping in. When we considered how long we will have to keep on rolling around on these \"\"soft\"\" beds and continue going through all kinds of hardships - it made us feel even worse.\"'),(9,3,'Item',50,0,'Kursk'),(10,3,'Item',40,0,'1899-07-09'),(11,3,'Item',1,0,'\"At 10 o\'clock at night we arrived in KURSK. Kursk is a very big city. The train was delayed and we just waited for two hours. As we got out of our train cars a group of soldiers came up to us. We asked them whether there was any news. They said that everything was quiet around here and they hadn\'t heard any news.\r\n\r\nWe were given permission to go into the city. Kursk is a very big city but very few Jews were to be found here.\r\n\r\nAs we got into the city in the dark of night, a whole bright world opened up before us. We went shopping for food and we did really well: we bought rolls, bread, sugar tea, salami, cigarette paper and things like that which a soldier needs. However. One soldier paid for his purchase and five did not. The merchants made a profit anyway. They knew that we were going to war and they probably figured:\"\" Let them go!\"\" They also knew that we were the first brigades coming and they will do a lot more business.\r\n\r\nAt 10 o\'clock at night we left Kursk . A big crowd came to see us off at the railroad station and everybody was curious to find out where we were going. The band played as we got into our train cars. The third bell rang, the locomotive gave a whistle and we were moving away. The people were bowing to us and we were singing songs and shouting: \"\"Hurrah! Hurrah!\"\"\r\n\r\nAn unusual think happened as we were leaving Kursk. Several soldiers were left behind because they got drunk - dead drunk - and we didn\'t know where to find them.\"'),(12,4,'Item',50,0,'Penza'),(13,4,'Item',40,0,'1899-07-14'),(14,4,'Item',1,0,'\"On July 14th we arrived in a big city called PENDZE. A lot of people gathered around when we arrived. We went to eat dinner.\r\n\r\nIn the midst of all this. an old man, holding an alms box, came up to me and offered to pray in church for my successful return if I would put five kopecks in his alms box. My reply to him was: \"\"You came with nothing - you\'ll leave with nothing. And I thought to myself: \"\"Why don\'t you give me five kopecks and then I will pray for you- which you leave me alone and get lost.\"\" We didn\'t think much of this alms-giving business.\r\n\r\nMeanwhile, a train arrived (from the opposite direction) carrying Russian settlers who had to flee for their lives. These people were civilian settlers who lived near Manchuria.\r\n\r\nWhen the war started the Chinese attacked them robbed them and burned their homes. They had to run for their lives and now they were returning to Russia. They were poor and looked threadbare and it was a pity to look at them. They were traveling at government expense just like soldiers: fifty people in one freight car, including women and children. They were receiving (from the government) half a pound of meat and a pound of bread for a mere three kopecks and borscht and tea for free.\"'),(15,5,'Item',50,0,'Konsk'),(16,5,'Item',40,0,'1899-07-25'),(17,5,'Item',1,0,'\"On July 25th we arrived in KONTSK. As I was eating dinner I met two Jews from Warsaw who spent five years of exile here for a fraudulent deal. Their five years of exile were over and since they were about to return to Warsaw I gave them a letter to pass on to my family.\"'),(18,6,'Item',50,0,'Stretensk'),(19,6,'Item',40,0,'1899-08-10'),(20,6,'Item',1,0,'\"On August 10th we arrived at Stretensk in the CHABAROVSK region. This is where the Siberian railroad ended.\r\n\r\nUntil now we were in pretty good spirits. We traveled on dry land and with the shouts of \"\"Hurrah! Hurrah!\"\" and the singing of songs we traveled across European Russia and much of Siberia. Now begins Asia. It reeks already of China and Manchuria.\r\n\r\nStretensk is a harbor and a Cossack dty. Here live mainly Cossacks. You can find Jews too but very few in number.\r\n\r\nWe got off the train and took all our belongings out of the train car and all the regimental baggage as well. We said good-bye to the train cars that carried us such a long way.\r\n\r\nWe remained at Stretinsk harbor for half a day. We needed to continue our journey by railroad but the Chinese damaged the railroad tracks so that the Russians wouldn\'t be able to bring any reinforcements to the battle area. For that reason we had to stay here. We sent a telegram asking for instructions on how we should proceed and what we should do. We were instructed to continue our journey on water. The waterway here was the river Shilka (or Shilke).\"'),(21,7,'Item',50,0,'Amur'),(22,7,'Item',40,0,'1899-08-13'),(23,7,'Item',1,0,'\"On August 13th our ship entered the Amur River. One side of the river belongs to the\r\nChinese - the other to the Russians.\r\n\r\nNow when we stop over to sleep and to cook our dinner we are each issued fifty rounds of ammunition. They also appointed guard posts all around the area to prevent an unexpected attack on us.\r\n\r\nAs we traveled along the river we saw Chinese villages - they had all been burned and destroyed and you didn\'t see a living soul; all that was left were the wooden chimneys of their homes.	We saw fields which had been sown with all kinds of good things and also vineyards which the Chinese left behind as they fled when the battle began.\r\n\r\nA couple of nights we stopped over near forests where wild animals were roaming and snakes could be found as well.	Here we couldn\'t sleep anymore because we were afraid for our \"\"behinds.\"\" We were already sick and tired of this traveling and all the \"\"conveniences\"\" which we enjoy - the eating and the sleeping which we can\'t enjoy neither by day nor by night.	But - we have to put up with it.\"'),(24,8,'Item',50,0,'San Dzian'),(25,8,'Item',40,0,'1899-09-26'),(26,8,'Item',1,0,'\"We entered the town - it was deserted, not even a dog was to be seen. When the Chinese heard that soldiers were coming they fled with their wives and children and left all their property unattended.\r\n\r\nThe elder of the town remained and he showed us the fort where Chinese soldiers had been stationed but they fled.\r\n\r\nWe entered the fort. We have to settle down here so we immediately started working like horses. Everything needed fixing. Chinese houses have no window panes and no ovens.  They have empty rooms and holes in the walls and here winter is coming. We started fixing things up. We need a kitchen to cook food and an oven to bake bread and quarters with window panes. However, there are no window panes to be had. That is not the Chinese style.         We had to make windows their style that is paper smeared with oil.  We worked eight hours a day. Everything was fixed up in the best way possible. Even dogs may stay here now not just soldiers. Anyway, it is nice and warm except that you can choke from the smoke. First of all they told us to bring in all the things we would need.        We bought flour and we had our provisions brought in and we were all settled in here.\r\n\r\nThen our \"\"boss\"\" arrived, the brigade general Kotnievitch. We all jumped in parade formation and he reviewed each of us carefully and said: \"\"see to it that you fix yourself up because you look poorly. We will spend the winter here and then we will go back to Russia, to our old place.\"\"        We were very happy to hear this news - it really refreshed each one of us.\r\n\r\nThe 17th of December we looked up and here was our exchange unit. We got dressed and moved out on foot to Fen Dziah. As we were marching we thanked God that we survived the first round of Hell.\"'),(27,9,'Item',50,0,'Niklosk'),(28,9,'Item',40,0,'1900-01-07'),(29,9,'Item',1,0,'\"On Jan. 7 we arrived in Nikolsk. We disembarked from the train and a new world greeted us. We can now see white faces for up to now we have only seen the dark­ skinned Chinese. Many of us lifted our hands to the Living God that He helped us in our needs and troubles without end and protected us from all evil. And we prayed for continued help that we should not have to face again the evil, dark-as-the-devil Chinese with their long braids.\r\n\r\nWe arrive at the railroad station in Nikolsk as the music is playing. We disembark from the train. We were happy to be finished with Manchuria where we could have gotten killed.  We were delighted to see a Russian city again in front of us.  Then as we look around we see people dark faced as the    Chinese.	They are dressed from head to toe in white and are wearing fedora style hats. At first we thought that they were ghosts, but ghosts don\'t wear fedoras. We asked around what kind of animal this was and we were told that these were Koreans.\r\n\r\nNikolsk is a large Russian city.   Here you find people of various nationalities. Russians, Poles, Chinese and Koreans.  You  even  find  a couple  of  Jews  here and the  dark-faced  Japanese  who  are  all  dressed  in  European  clothes.\"'),(30,10,'Item',50,0,'Vladivostok'),(31,10,'Item',40,0,'1900-03-05'),(32,10,'Item',1,0,'\"Vladivostock is an important sea-port and many large ships are waiting here to loaded or unloaded.\r\n\r\nAs we got off the train we were all very happy that we were about to leave for Russia. We stacked up our rifles and busied ourselves removing our gear from the baggage cars. We were taking home several flags as well as a few Chinese artillery pieces, rifles, swords and a small Chinese boy. These things were to serve as our remembrances of China.\r\n\r\nEverything was taken out of the train, laid down on the ground and then was loaded onto the ship.\r\nA Chinese baron was traveling with us. We were also carrying a load of long Chinese pipes.\r\n\r\nWhen everything was loaded we went to the baths. After a good wash we boarded the boat. So ended the march in Manchuria. We thanked God that we overcame everything thus far and so far from home - and now we have arrived at this point.\"'),(33,11,'Item',50,0,'Nagasaki'),(34,11,'Item',40,0,'1901-03-09'),(35,11,'Item',1,0,'\"After sailing for three days we arrive at an island in the Sea of Japan. On the 9th of March at 5:00 in the afternoon, we enter the port city of Nagasaki. After the ship has docked at the pier a Japanese inspection crew boards us. They are to inspect both cargo and passengers.	As it turns out, it\'s a mere formality and they depart as soon as they arrived. There are ships from many countries anchored at the Port of Nagasaki; we see flags from various nations - American. English. French and Japanese.\r\n\r\nSuddenly, a flotilla of small boats approaches our vessel. They are packed full of goods for sale; we can buy anything imaginable. All kinds of food stuff, baked goods, citrus fruit, cigarettes and soft drinks. They also have gold and silver jewelry. The desire to purchase something is very strong but most of us have little or no money, so we have to satisfy ourselves with just enjoying the sight. Some passengers got into a fist fight with the vendors after not being able to pay for their purchase.	One person got beat up to serve as an example for others, not to take merchandise   for which he was not able to pay. The cheapest of all goods was tea 25 to 30 kopeks a pound where as in Russia, it would cost 2 or even 3 Rubles,\r\n\r\nEach day for three days, the little boats kept coming and the bartering went on. Everything that one\'s heart desired was for sale. Clothing especially, was very inexpensive. Things such as shirts, pants, socks, etc.\r\n\r\nFinally, our boat loads up with fuel (coal), water, food and other supplies and on March 12th, in the morning, we leave Nagasaki. Our destination - Singapore.\r\n\r\nSoon we notice a drastic change in the weather. It\'s getting very hot and we feel the heat increasing as the day progresses. We receive orders to don our white outfits – pants, shirts and white cap. These are supposed to protect us from the sun and heat and were especially made for us in Nikolsk. When we look at ourselves and each other, we can\'t help but laugh, because we look like the walking dead!\r\n\r\nWe sail on and see nothing but endless seas, blue sky and a hot sun. Occasionally, we pass another boat or small island, and then again, the same monotony.\r\n\r\nThe heat becomes almost unbearable.	Our new clothing is getting wet and heavy, as we sweat profusely. Had it not been for our sense of feeling ashamed, we would have walked about naked!\r\n\r\nOur boat begins to rock back and forth and from side to side. A motion disagreeable to most of us and we begin another bout with sea sickness.  We are trying to stay on deck since sea sickness below deck is an even worse experience. But there is little or no room for everybody, and it\'s impossible to find a shady spot to be protected from the punishing sun rays.\r\n\r\nEvery other day is laundry day. We have to do it ourselves and the only water we can use is salt water.	We find the salt water needs more soap to make suds and that presents a problem, as well. We have to do the best we can under the circumstances and hopefully our soap supply will outlast our dirt.\"'),(36,12,'Item',50,0,'Samar'),(37,12,'Item',40,0,'1899-07-15'),(38,12,'Item',1,0,'\"At noon we arrived in Samar - also a very big day.  We had our meal near the railroad station and then each one of us received two glasses of beer.  We didn\'t know where this beer came from or who had donated it, Later we learned that there was a wealthy brewer here in Samar and that he treated the entire brigade to free beer because we were going to war. That was very nice and I wouldn\'t have minded having some beer every day - and some food as well.\r\n\r\nAfter we had the beer we went into the city. The city of Samar is very big but very few Jews could be found here. Those who lived here were all tradesmen who received residence-permits because deep inside Russia (outside the pale of settlement) Jews were not allowed to live unless they received special permission. And when you met one of these Jews, you would never recognize that it was a Jew because they had become thoroughly crucified, spoke only Russian and knew very little of their Jewish heritage.\r\n\r\nWe left Samar as the band was playing merrily\r\n.\"');
/*!40000 ALTER TABLE `omeka_element_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_elements`
--

DROP TABLE IF EXISTS `omeka_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `element_set_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_element_set_id` (`element_set_id`,`name`),
  UNIQUE KEY `order_element_set_id` (`element_set_id`,`order`),
  KEY `element_set_id` (`element_set_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_elements`
--

LOCK TABLES `omeka_elements` WRITE;
/*!40000 ALTER TABLE `omeka_elements` DISABLE KEYS */;
INSERT INTO `omeka_elements` VALUES (1,3,NULL,'Text','Any textual data included in the document',NULL),(2,3,NULL,'Interviewer','The person(s) performing the interview',NULL),(3,3,NULL,'Interviewee','The person(s) being interviewed',NULL),(4,3,NULL,'Location','The location of the interview',NULL),(5,3,NULL,'Transcription','Any written text transcribed from a sound',NULL),(6,3,NULL,'Local URL','The URL of the local directory containing all assets of the website',NULL),(7,3,NULL,'Original Format','The type of object, such as painting, sculpture, paper, photo, and additional data',NULL),(10,3,NULL,'Physical Dimensions','The actual physical size of the original image',NULL),(11,3,NULL,'Duration','Length of time involved (seconds, minutes, hours, days, class periods, etc.)',NULL),(12,3,NULL,'Compression','Type/rate of compression for moving image file (i.e. MPEG-4)',NULL),(13,3,NULL,'Producer','Name (or names) of the person who produced the video',NULL),(14,3,NULL,'Director','Name (or names) of the person who produced the video',NULL),(15,3,NULL,'Bit Rate/Frequency','Rate at which bits are transferred (i.e. 96 kbit/s would be FM quality audio)',NULL),(16,3,NULL,'Time Summary','A summary of an interview given for different time stamps throughout the interview',NULL),(17,3,NULL,'Email Body','The main body of the email, including all replied and forwarded text and headers',NULL),(18,3,NULL,'Subject Line','The content of the subject line of the email',NULL),(19,3,NULL,'From','The name and email address of the person sending the email',NULL),(20,3,NULL,'To','The name(s) and email address(es) of the person to whom the email was sent',NULL),(21,3,NULL,'CC','The name(s) and email address(es) of the person to whom the email was carbon copied',NULL),(22,3,NULL,'BCC','The name(s) and email address(es) of the person to whom the email was blind carbon copied',NULL),(23,3,NULL,'Number of Attachments','The number of attachments to the email',NULL),(24,3,NULL,'Standards','',NULL),(25,3,NULL,'Objectives','',NULL),(26,3,NULL,'Materials','',NULL),(27,3,NULL,'Lesson Plan Text','',NULL),(28,3,NULL,'URL','',NULL),(29,3,NULL,'Event Type','',NULL),(30,3,NULL,'Participants','Names of individuals or groups participating in the event',NULL),(31,3,NULL,'Birth Date','',NULL),(32,3,NULL,'Birthplace','',NULL),(33,3,NULL,'Death Date','',NULL),(34,3,NULL,'Occupation','',NULL),(35,3,NULL,'Biographical Text','',NULL),(36,3,NULL,'Bibliography','',NULL),(37,1,8,'Contributor','An entity responsible for making contributions to the resource',NULL),(38,1,15,'Coverage','The spatial or temporal topic of the resource, the spatial applicability of the resource, or the jurisdiction under which the resource is relevant',NULL),(39,1,4,'Creator','An entity primarily responsible for making the resource',NULL),(40,1,7,'Date','A point or period of time associated with an event in the lifecycle of the resource',NULL),(41,1,3,'Description','An account of the resource',NULL),(42,1,11,'Format','The file format, physical medium, or dimensions of the resource',NULL),(43,1,14,'Identifier','An unambiguous reference to the resource within a given context',NULL),(44,1,12,'Language','A language of the resource',NULL),(45,1,6,'Publisher','An entity responsible for making the resource available',NULL),(46,1,10,'Relation','A related resource',NULL),(47,1,9,'Rights','Information about rights held in and over the resource',NULL),(48,1,5,'Source','A related resource from which the described resource is derived',NULL),(49,1,2,'Subject','The topic of the resource',NULL),(50,1,1,'Title','A name given to the resource',NULL),(51,1,13,'Type','The nature or genre of the resource',NULL);
/*!40000 ALTER TABLE `omeka_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_files`
--

DROP TABLE IF EXISTS `omeka_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `size` int(10) unsigned NOT NULL,
  `has_derivative_image` tinyint(1) NOT NULL,
  `authentication` char(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_os` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` text COLLATE utf8_unicode_ci NOT NULL,
  `original_filename` text COLLATE utf8_unicode_ci NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added` timestamp NOT NULL DEFAULT '2000-01-01 05:00:00',
  `stored` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_files`
--

LOCK TABLES `omeka_files` WRITE;
/*!40000 ALTER TABLE `omeka_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_item_types`
--

DROP TABLE IF EXISTS `omeka_item_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_item_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_item_types`
--

LOCK TABLES `omeka_item_types` WRITE;
/*!40000 ALTER TABLE `omeka_item_types` DISABLE KEYS */;
INSERT INTO `omeka_item_types` VALUES (1,'Text','A resource consisting primarily of words for reading. Examples include books, letters, dissertations, poems, newspapers, articles, archives of mailing lists. Note that facsimiles or images of texts are still of the genre Text.'),(3,'Moving Image','A series of visual representations imparting an impression of motion when shown in succession. Examples include animations, movies, television programs, videos, zoetropes, or visual output from a simulation.'),(4,'Oral History','A resource containing historical information obtained in interviews with persons having firsthand knowledge.'),(5,'Sound','A resource primarily intended to be heard. Examples include a music playback file format, an audio compact disc, and recorded speech or sounds.'),(6,'Still Image','A static visual representation. Examples include paintings, drawings, graphic designs, plans and maps. Recommended best practice is to assign the type Text to images of textual materials.'),(7,'Website','A resource comprising of a web page or web pages and all related assets ( such as images, sound and video files, etc. ).'),(8,'Event','A non-persistent, time-based occurrence. Metadata for an event provides descriptive information that is the basis for discovery of the purpose, location, duration, and responsible agents associated with an event. Examples include an exhibition, webcast, conference, workshop, open day, performance, battle, trial, wedding, tea party, conflagration.'),(9,'Email','A resource containing textual messages and binary attachments sent electronically from one person to another or one person to many people.'),(10,'Lesson Plan','A resource that gives a detailed description of a course of instruction.'),(11,'Hyperlink','A link, or reference, to another resource on the Internet.'),(12,'Person','An individual.'),(13,'Interactive Resource','A resource requiring interaction from the user to be understood, executed, or experienced. Examples include forms on Web pages, applets, multimedia learning objects, chat services, or virtual reality environments.'),(14,'Dataset','Data encoded in a defined structure. Examples include lists, tables, and databases. A dataset may be useful for direct machine processing.'),(15,'Physical Object','An inanimate, three-dimensional object or substance. Note that digital representations of, or surrogates for, these objects should use Moving Image, Still Image, Text or one of the other types.'),(16,'Service','A system that provides one or more functions. Examples include a photocopying service, a banking service, an authentication service, interlibrary loans, a Z39.50 or Web server.'),(17,'Software','A computer program in source or compiled form. Examples include a C source file, MS-Windows .exe executable, or Perl script.');
/*!40000 ALTER TABLE `omeka_item_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_item_types_elements`
--

DROP TABLE IF EXISTS `omeka_item_types_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_item_types_elements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_type_id` int(10) unsigned NOT NULL,
  `element_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_type_id_element_id` (`item_type_id`,`element_id`),
  KEY `item_type_id` (`item_type_id`),
  KEY `element_id` (`element_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_item_types_elements`
--

LOCK TABLES `omeka_item_types_elements` WRITE;
/*!40000 ALTER TABLE `omeka_item_types_elements` DISABLE KEYS */;
INSERT INTO `omeka_item_types_elements` VALUES (1,1,7,NULL),(2,1,1,NULL),(3,6,7,NULL),(6,6,10,NULL),(7,3,7,NULL),(8,3,11,NULL),(9,3,12,NULL),(10,3,13,NULL),(11,3,14,NULL),(12,3,5,NULL),(13,5,7,NULL),(14,5,11,NULL),(15,5,15,NULL),(16,5,5,NULL),(17,4,7,NULL),(18,4,11,NULL),(19,4,15,NULL),(20,4,5,NULL),(21,4,2,NULL),(22,4,3,NULL),(23,4,4,NULL),(24,4,16,NULL),(25,9,17,NULL),(26,9,18,NULL),(27,9,20,NULL),(28,9,19,NULL),(29,9,21,NULL),(30,9,22,NULL),(31,9,23,NULL),(32,10,24,NULL),(33,10,25,NULL),(34,10,26,NULL),(35,10,11,NULL),(36,10,27,NULL),(37,7,6,NULL),(38,11,28,NULL),(39,8,29,NULL),(40,8,30,NULL),(41,8,11,NULL),(42,12,31,NULL),(43,12,32,NULL),(44,12,33,NULL),(45,12,34,NULL),(46,12,35,NULL),(47,12,36,NULL);
/*!40000 ALTER TABLE `omeka_item_types_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_items`
--

DROP TABLE IF EXISTS `omeka_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_type_id` int(10) unsigned DEFAULT NULL,
  `collection_id` int(10) unsigned DEFAULT NULL,
  `featured` tinyint(4) NOT NULL,
  `public` tinyint(4) NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added` timestamp NOT NULL DEFAULT '2000-01-01 05:00:00',
  `owner_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_type_id` (`item_type_id`),
  KEY `collection_id` (`collection_id`),
  KEY `public` (`public`),
  KEY `featured` (`featured`),
  KEY `owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_items`
--

LOCK TABLES `omeka_items` WRITE;
/*!40000 ALTER TABLE `omeka_items` DISABLE KEYS */;
INSERT INTO `omeka_items` VALUES (1,1,1,0,1,'2016-06-18 01:30:38','2016-06-14 22:15:16',1),(2,1,1,0,1,'2016-06-18 01:31:08','2016-06-14 22:17:28',1),(3,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:18:41',1),(4,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:19:30',1),(5,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:20:42',1),(6,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:22:06',1),(7,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:23:02',1),(8,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:24:03',1),(9,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:25:08',1),(10,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:25:50',1),(11,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:26:49',1),(12,1,1,0,1,'2016-06-18 00:25:07','2016-06-14 22:28:26',1);
/*!40000 ALTER TABLE `omeka_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_keys`
--

DROP TABLE IF EXISTS `omeka_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_keys` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `label` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `key` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varbinary(16) DEFAULT NULL,
  `accessed` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_keys`
--

LOCK TABLES `omeka_keys` WRITE;
/*!40000 ALTER TABLE `omeka_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_neatline_exhibits`
--

DROP TABLE IF EXISTS `omeka_neatline_exhibits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_neatline_exhibits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(10) unsigned NOT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NULL DEFAULT NULL,
  `published` timestamp NULL DEFAULT NULL,
  `item_query` text COLLATE utf8_unicode_ci,
  `spatial_layers` text COLLATE utf8_unicode_ci,
  `spatial_layer` text COLLATE utf8_unicode_ci,
  `image_layer` text COLLATE utf8_unicode_ci,
  `image_height` smallint(5) unsigned DEFAULT NULL,
  `image_width` smallint(5) unsigned DEFAULT NULL,
  `zoom_levels` smallint(5) unsigned DEFAULT NULL,
  `wms_address` text COLLATE utf8_unicode_ci,
  `wms_layers` text COLLATE utf8_unicode_ci,
  `widgets` text COLLATE utf8_unicode_ci,
  `title` text COLLATE utf8_unicode_ci,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `narrative` longtext COLLATE utf8_unicode_ci,
  `spatial_querying` tinyint(1) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `styles` text COLLATE utf8_unicode_ci,
  `map_focus` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `map_zoom` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_neatline_exhibits`
--

LOCK TABLES `omeka_neatline_exhibits` WRITE;
/*!40000 ALTER TABLE `omeka_neatline_exhibits` DISABLE KEYS */;
INSERT INTO `omeka_neatline_exhibits` VALUES (1,1,'2016-06-17 19:05:11','2016-06-22 08:21:18','2016-06-17 11:08:25','a:5:{s:5:\"range\";s:0:\"\";s:10:\"collection\";s:1:\"1\";s:4:\"type\";s:1:\"1\";s:4:\"tags\";s:0:\"\";s:13:\"submit_search\";s:12:\"Import Items\";}','OpenStreetMap,GooglePhysical,GoogleStreets,GoogleHybrid,GoogleSatellite,StamenToner','GoogleSatellite',NULL,NULL,NULL,20,NULL,NULL,'Waypoints,Simile','Tour Prototype 1','tour-prototype-1',NULL,1,1,'','5843457.9375321,5531594.8621722',4);
/*!40000 ALTER TABLE `omeka_neatline_exhibits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_neatline_records`
--

DROP TABLE IF EXISTS `omeka_neatline_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_neatline_records` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `exhibit_id` int(10) unsigned DEFAULT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NULL DEFAULT NULL,
  `is_coverage` tinyint(1) NOT NULL,
  `is_wms` tinyint(1) NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` mediumtext COLLATE utf8_unicode_ci,
  `item_title` mediumtext COLLATE utf8_unicode_ci,
  `body` mediumtext COLLATE utf8_unicode_ci,
  `coverage` geometry NOT NULL,
  `tags` text COLLATE utf8_unicode_ci,
  `widgets` text COLLATE utf8_unicode_ci,
  `presenter` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fill_color` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fill_color_select` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stroke_color` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stroke_color_select` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fill_opacity` decimal(3,2) DEFAULT NULL,
  `fill_opacity_select` decimal(3,2) DEFAULT NULL,
  `stroke_opacity` decimal(3,2) DEFAULT NULL,
  `stroke_opacity_select` decimal(3,2) DEFAULT NULL,
  `stroke_width` int(10) unsigned DEFAULT NULL,
  `point_radius` int(10) unsigned DEFAULT NULL,
  `zindex` int(10) unsigned DEFAULT NULL,
  `weight` int(10) unsigned DEFAULT NULL,
  `start_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `after_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `before_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `point_image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wms_address` text COLLATE utf8_unicode_ci,
  `wms_layers` text COLLATE utf8_unicode_ci,
  `min_zoom` int(10) unsigned DEFAULT NULL,
  `max_zoom` int(10) unsigned DEFAULT NULL,
  `map_zoom` int(10) unsigned DEFAULT NULL,
  `map_focus` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `added` (`added`),
  KEY `exhibit_id` (`exhibit_id`,`item_id`),
  KEY `min_zoom` (`min_zoom`,`max_zoom`),
  SPATIAL KEY `coverage` (`coverage`),
  FULLTEXT KEY `item_title` (`item_title`,`title`,`body`,`slug`),
  FULLTEXT KEY `tags` (`tags`),
  FULLTEXT KEY `widgets` (`widgets`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_neatline_records`
--

LOCK TABLES `omeka_neatline_records` WRITE;
/*!40000 ALTER TABLE `omeka_neatline_records` DISABLE KEYS */;
INSERT INTO `omeka_neatline_records` VALUES (1,1,3,1,'2016-06-14 22:18:41','2016-06-22 08:21:36',1,0,NULL,NULL,'Kursk',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0����u�NA��W�YA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,2,'1899-07-09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'3919690.8099185,6653690.4372423'),(2,1,4,1,'2016-06-14 22:19:30','2016-06-22 08:21:36',1,0,NULL,NULL,'Penza',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0`�2%�SA����S�ZA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,3,'1899-07-14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'4901753.7491898,6928863.7390307'),(3,1,5,1,'2016-06-14 22:20:42','2016-06-22 08:21:36',1,0,NULL,NULL,'Konsk',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0�6��SdA@E�eY�\\A',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,5,'1899-07-25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'10553201.871696,7474929.8690235'),(4,1,6,1,'2016-06-14 22:22:06','2016-06-22 08:21:36',1,0,NULL,NULL,'Stretensk',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0i6��k�hA%�b0�ZA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,6,'1899-08-10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'12988179.84441,6775072.4381423'),(5,1,7,1,'2016-06-14 22:23:02','2016-06-22 08:21:36',1,0,NULL,NULL,'Amur',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0��E�8YmAu�Q�;YA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,7,'1899-08-13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'15277621.71529,6515492.2901218'),(6,1,8,1,'2016-06-14 22:24:03','2016-06-17 13:31:21',0,0,NULL,NULL,'San Dzian',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,NULL,'StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,1,9,1,'2016-06-14 22:25:08','2016-06-17 13:31:21',0,0,NULL,NULL,'Niklosk',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',NULL,NULL,'StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,1,10,1,'2016-06-14 22:25:50','2016-06-22 08:21:36',1,0,NULL,NULL,'Vladivostok',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0ܷک�lA\\��>]TA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,8,'1900-03-05','1901-03-05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'14602529.881568,5205667.3736098'),(9,1,11,1,'2016-06-14 22:26:49','2016-06-22 08:21:36',1,0,NULL,NULL,'Nagasaki',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0h=��w�kA(uawMA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,9,'1901-03-09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'14362823.360898,3776600.6929889'),(10,1,12,1,'2016-06-14 22:28:26','2016-06-22 08:21:36',1,0,NULL,NULL,'Samar',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\04%��FSUA��+�5�ZA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,4,'1899-07-15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'5488790.1263382,6931309.7239355'),(11,1,1,1,'2016-06-14 22:15:16','2016-06-22 08:21:36',1,0,NULL,NULL,'Zhmerinka','<p><a href=\"http://localhost/omeka/items/show/1\">Click Here to Comment</a></p>\n<p><a href=\"http://localhost/omeka/corrections/index/add/item_id/1\">Click Here to Suggest a Correction</a></p>','\0\0\0\0\0\0\0\0\0\0\0\0\06�}8��GA�Poy�WA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,0,'1899-07-07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'3034244.2743864,6192010.7864641'),(12,1,2,1,'2016-06-14 22:17:28','2016-06-22 08:21:36',1,0,NULL,NULL,'Vinitse',NULL,'\0\0\0\0\0\0\0\0\0\0\0\0\0�$}�-HA�V&XA',NULL,'Waypoints,Simile','StaticBubble','#00aeff','#00aeff','#000000','#000000',0.30,0.40,0.90,1.00,2,10,NULL,1,'1899-07-07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,'3062373.1007913,6219528.116643');
/*!40000 ALTER TABLE `omeka_neatline_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_neatline_simile_exhibit_expansions`
--

DROP TABLE IF EXISTS `omeka_neatline_simile_exhibit_expansions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_neatline_simile_exhibit_expansions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `simile_default_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `simile_interval_unit` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `simile_interval_pixels` int(10) unsigned DEFAULT NULL,
  `simile_tape_height` int(10) unsigned DEFAULT NULL,
  `simile_track_height` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_neatline_simile_exhibit_expansions`
--

LOCK TABLES `omeka_neatline_simile_exhibit_expansions` WRITE;
/*!40000 ALTER TABLE `omeka_neatline_simile_exhibit_expansions` DISABLE KEYS */;
INSERT INTO `omeka_neatline_simile_exhibit_expansions` VALUES (1,1,'July 7, 1899','WEEK',100,10,30);
/*!40000 ALTER TABLE `omeka_neatline_simile_exhibit_expansions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_options`
--

DROP TABLE IF EXISTS `omeka_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_options`
--

LOCK TABLES `omeka_options` WRITE;
/*!40000 ALTER TABLE `omeka_options` DISABLE KEYS */;
INSERT INTO `omeka_options` VALUES (1,'omeka_version','2.4.1'),(2,'administrator_email','cs4dh@faokryn.com'),(3,'copyright',''),(4,'site_title','MAGIC Digitial Humanities Tour Prototype'),(5,'author',''),(6,'description',''),(7,'thumbnail_constraint','200'),(8,'square_thumbnail_constraint','200'),(9,'fullsize_constraint','800'),(10,'per_page_admin','10'),(11,'per_page_public','10'),(12,'show_empty_elements','0'),(13,'path_to_convert','/usr/local/bin'),(14,'admin_theme','default'),(16,'file_extension_whitelist','aac,aif,aiff,asf,asx,avi,bmp,c,cc,class,css,divx,doc,docx,exe,gif,gz,gzip,h,ico,j2k,jp2,jpe,jpeg,jpg,m4a,m4v,mdb,mid,midi,mov,mp2,mp3,mp4,mpa,mpe,mpeg,mpg,mpp,odb,odc,odf,odg,odp,ods,odt,ogg,opus,pdf,png,pot,pps,ppt,pptx,qt,ra,ram,rtf,rtx,swf,tar,tif,tiff,txt,wav,wax,webm,wma,wmv,wmx,wri,xla,xls,xlsx,xlt,xlw,zip'),(17,'file_mime_type_whitelist','application/msword,application/ogg,application/pdf,application/rtf,application/vnd.ms-access,application/vnd.ms-excel,application/vnd.ms-powerpoint,application/vnd.ms-project,application/vnd.ms-write,application/vnd.oasis.opendocument.chart,application/vnd.oasis.opendocument.database,application/vnd.oasis.opendocument.formula,application/vnd.oasis.opendocument.graphics,application/vnd.oasis.opendocument.presentation,application/vnd.oasis.opendocument.spreadsheet,application/vnd.oasis.opendocument.text,application/x-ms-wmp,application/x-ogg,application/x-gzip,application/x-msdownload,application/x-shockwave-flash,application/x-tar,application/zip,audio/aac,audio/aiff,audio/mid,audio/midi,audio/mp3,audio/mp4,audio/mpeg,audio/mpeg3,audio/ogg,audio/wav,audio/wma,audio/x-aac,audio/x-aiff,audio/x-m4a,audio/x-midi,audio/x-mp3,audio/x-mp4,audio/x-mpeg,audio/x-mpeg3,audio/x-mpegaudio,audio/x-ms-wax,audio/x-realaudio,audio/x-wav,audio/x-wma,image/bmp,image/gif,image/icon,image/jpeg,image/pjpeg,image/png,image/tiff,image/x-icon,image/x-ms-bmp,text/css,text/plain,text/richtext,text/rtf,video/asf,video/avi,video/divx,video/mp4,video/mpeg,video/msvideo,video/ogg,video/quicktime,video/webm,video/x-m4v,video/x-ms-wmv,video/x-msvideo'),(18,'disable_default_file_validation',''),(20,'display_system_info','1'),(21,'html_purifier_is_enabled','1'),(22,'html_purifier_allowed_html_elements','p,br,strong,em,span,div,ul,ol,li,a,h1,h2,h3,h4,h5,h6,address,pre,table,tr,td,blockquote,thead,tfoot,tbody,th,dl,dt,dd,q,small,strike,sup,sub,b,i,big,small,tt'),(23,'html_purifier_allowed_html_attributes','*.style,*.class,a.href,a.title,a.target'),(24,'tag_delimiter',','),(26,'search_record_types','a:3:{s:4:\"Item\";s:4:\"Item\";s:4:\"File\";s:4:\"File\";s:10:\"Collection\";s:10:\"Collection\";}'),(27,'api_enable',''),(28,'api_per_page','50'),(29,'show_element_set_headings','1'),(37,'commenting_reqapp_comment_roles','a:0:{}'),(38,'commenting_view_roles','a:0:{}'),(39,'commenting_threaded','1'),(40,'commenting_comments_label','Discussion'),(41,'commenting_allow_public','0'),(42,'commenting_require_public_moderation','0'),(43,'commenting_moderate_roles','a:1:{i:0;s:5:\"admin\";}'),(44,'commenting_comment_roles','a:3:{i:0;s:5:\"admin\";i:1;s:10:\"researcher\";i:2;s:11:\"contributor\";}'),(45,'commenting_allow_public_view','1'),(46,'commenting_wpapi_key',''),(47,'install_plugin','Save Changes'),(48,'csrf_token','71fc4421af33a90b38fc527fe62689a2'),(50,'corrections_email',''),(51,'corrections_text',''),(52,'corrections_elements','{\"Dublin Core\":[\"Date\"],\"Item Type Metadata\":[\"Location\"]}'),(54,'public_theme','seasons'),(55,'theme_seasons_options','a:13:{s:11:\"style_sheet\";s:6:\"winter\";s:4:\"logo\";N;s:21:\"display_featured_item\";s:1:\"1\";s:27:\"display_featured_collection\";s:1:\"1\";s:24:\"display_featured_exhibit\";s:1:\"1\";s:21:\"homepage_recent_items\";N;s:13:\"homepage_text\";N;s:11:\"footer_text\";N;s:24:\"display_footer_copyright\";s:1:\"0\";s:17:\"item_file_gallery\";s:1:\"0\";s:19:\"use_advanced_search\";s:1:\"1\";s:12:\"exhibits_nav\";s:4:\"side\";s:17:\"theme_config_csrf\";N;}'),(57,'simple_pages_filter_page_content','0'),(66,'public_navigation_main','[{\"uid\":\"\\/omeka\\/neatline\",\"can_delete\":false,\"type\":\"Omeka_Navigation_Page_Uri\",\"label\":\"Neatline\",\"fragment\":null,\"id\":null,\"class\":null,\"title\":null,\"target\":null,\"accesskey\":null,\"rel\":[],\"rev\":[],\"customHtmlAttribs\":[],\"order\":1,\"resource\":null,\"privilege\":null,\"active\":false,\"visible\":false,\"pages\":[],\"uri\":\"\\/omeka\\/neatline\"},{\"uid\":\"\\/omeka\\/neatline\\/show\\/tour-prototype-1\",\"can_delete\":true,\"type\":\"Omeka_Navigation_Page_Uri\",\"label\":\"Take the Tour\",\"fragment\":null,\"id\":null,\"class\":null,\"title\":null,\"target\":null,\"accesskey\":null,\"rel\":[],\"rev\":[],\"customHtmlAttribs\":[],\"order\":2,\"resource\":null,\"privilege\":null,\"active\":false,\"visible\":true,\"pages\":[],\"uri\":\"\\/omeka\\/neatline\\/show\\/tour-prototype-1\"},{\"uid\":\"\\/omeka\\/items\\/browse\",\"can_delete\":false,\"type\":\"Omeka_Navigation_Page_Uri\",\"label\":\"Browse Items\",\"fragment\":null,\"id\":null,\"class\":null,\"title\":null,\"target\":null,\"accesskey\":null,\"rel\":[],\"rev\":[],\"customHtmlAttribs\":[],\"order\":3,\"resource\":null,\"privilege\":null,\"active\":false,\"visible\":true,\"pages\":[],\"uri\":\"\\/omeka\\/items\\/browse\"},{\"uid\":\"\\/omeka\\/collections\\/browse\",\"can_delete\":false,\"type\":\"Omeka_Navigation_Page_Uri\",\"label\":\"Browse Collections\",\"fragment\":null,\"id\":null,\"class\":null,\"title\":null,\"target\":null,\"accesskey\":null,\"rel\":[],\"rev\":[],\"customHtmlAttribs\":[],\"order\":4,\"resource\":null,\"privilege\":null,\"active\":false,\"visible\":false,\"pages\":[],\"uri\":\"\\/omeka\\/collections\\/browse\"},{\"uid\":\"\\/omeka\\/about\",\"can_delete\":false,\"type\":\"Omeka_Navigation_Page_Uri\",\"label\":\"About\",\"fragment\":null,\"id\":null,\"class\":null,\"title\":null,\"target\":null,\"accesskey\":null,\"rel\":[],\"rev\":[],\"customHtmlAttribs\":[],\"order\":5,\"resource\":null,\"privilege\":null,\"active\":false,\"visible\":false,\"pages\":[],\"uri\":\"\\/omeka\\/about\"},{\"uid\":\"\\/omeka\\/mysteries\",\"can_delete\":false,\"type\":\"Omeka_Navigation_Page_Uri\",\"label\":\"Contribute\",\"fragment\":null,\"id\":null,\"class\":null,\"title\":null,\"target\":null,\"accesskey\":null,\"rel\":[],\"rev\":[],\"customHtmlAttribs\":[],\"order\":6,\"resource\":null,\"privilege\":null,\"active\":false,\"visible\":true,\"pages\":[],\"uri\":\"\\/omeka\\/mysteries\"}]'),(67,'homepage_uri','/omeka/neatline/show/tour-prototype-1'),(68,'omeka_update','a:2:{s:14:\"latest_version\";s:5:\"2.4.1\";s:12:\"last_updated\";i:1467227982;}');
/*!40000 ALTER TABLE `omeka_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_plugins`
--

DROP TABLE IF EXISTS `omeka_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_plugins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL,
  `version` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `active_idx` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_plugins`
--

LOCK TABLES `omeka_plugins` WRITE;
/*!40000 ALTER TABLE `omeka_plugins` DISABLE KEYS */;
INSERT INTO `omeka_plugins` VALUES (3,'Neatline',1,'2.5.1'),(5,'NeatlineWaypoints',1,'2.0.2'),(6,'NeatlineSimile',1,'2.0.4'),(7,'Commenting',1,'2.1.2'),(8,'Corrections',1,'1.0'),(9,'SimplePages',1,'3.0.7');
/*!40000 ALTER TABLE `omeka_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_processes`
--

DROP TABLE IF EXISTS `omeka_processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_processes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned DEFAULT NULL,
  `status` enum('starting','in progress','completed','paused','error','stopped') COLLATE utf8_unicode_ci NOT NULL,
  `args` text COLLATE utf8_unicode_ci NOT NULL,
  `started` timestamp NOT NULL DEFAULT '2000-01-01 05:00:00',
  `stopped` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `pid` (`pid`),
  KEY `started` (`started`),
  KEY `stopped` (`stopped`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_processes`
--

LOCK TABLES `omeka_processes` WRITE;
/*!40000 ALTER TABLE `omeka_processes` DISABLE KEYS */;
INSERT INTO `omeka_processes` VALUES (1,'Omeka_Job_Process_Wrapper',1,NULL,'completed','a:1:{s:3:\"job\";s:210:\"{\"className\":\"Neatline_Job_ImportItems\",\"options\":{\"exhibit_id\":1,\"query\":{\"range\":\"\",\"collection\":\"1\",\"type\":\"\",\"tags\":\"\",\"submit_search\":\"Import Items\"}},\"createdAt\":\"2016-06-17T19:25:14+00:00\",\"createdBy\":1}\";}','2016-06-17 23:25:14','2016-06-17 23:25:15'),(2,'Omeka_Job_Process_Wrapper',1,NULL,'completed','a:1:{s:3:\"job\";s:211:\"{\"className\":\"Neatline_Job_ImportItems\",\"options\":{\"exhibit_id\":1,\"query\":{\"range\":\"\",\"collection\":\"1\",\"type\":\"1\",\"tags\":\"\",\"submit_search\":\"Import Items\"}},\"createdAt\":\"2016-06-17T20:22:54+00:00\",\"createdBy\":1}\";}','2016-06-18 00:22:54','2016-06-18 00:22:55'),(3,'Omeka_Job_Process_Wrapper',1,NULL,'completed','a:1:{s:3:\"job\";s:215:\"{\"className\":\"Neatline_Job_ImportItems\",\"options\":{\"exhibit_id\":1,\"query\":{\"range\":\"1-13\",\"collection\":\"1\",\"type\":\"1\",\"tags\":\"\",\"submit_search\":\"Import Items\"}},\"createdAt\":\"2016-06-17T20:24:28+00:00\",\"createdBy\":1}\";}','2016-06-18 00:24:28','2016-06-18 00:24:29'),(4,'Omeka_Job_Process_Wrapper',1,NULL,'completed','a:1:{s:3:\"job\";s:211:\"{\"className\":\"Neatline_Job_ImportItems\",\"options\":{\"exhibit_id\":1,\"query\":{\"range\":\"\",\"collection\":\"1\",\"type\":\"1\",\"tags\":\"\",\"submit_search\":\"Import Items\"}},\"createdAt\":\"2016-06-17T20:25:21+00:00\",\"createdBy\":1}\";}','2016-06-18 00:25:21','2016-06-18 00:25:22'),(5,'Omeka_Job_Process_Wrapper',1,NULL,'completed','a:1:{s:3:\"job\";s:211:\"{\"className\":\"Neatline_Job_ImportItems\",\"options\":{\"exhibit_id\":1,\"query\":{\"range\":\"\",\"collection\":\"1\",\"type\":\"1\",\"tags\":\"\",\"submit_search\":\"Import Items\"}},\"createdAt\":\"2016-06-17T21:31:20+00:00\",\"createdBy\":1}\";}','2016-06-18 01:31:20','2016-06-18 01:31:21');
/*!40000 ALTER TABLE `omeka_processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_records_tags`
--

DROP TABLE IF EXISTS `omeka_records_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_records_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_id` int(10) unsigned NOT NULL,
  `record_type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag_id` int(10) unsigned NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag` (`record_type`,`record_id`,`tag_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_records_tags`
--

LOCK TABLES `omeka_records_tags` WRITE;
/*!40000 ALTER TABLE `omeka_records_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_records_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_schema_migrations`
--

DROP TABLE IF EXISTS `omeka_schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_schema_migrations` (
  `version` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_schema_migrations`
--

LOCK TABLES `omeka_schema_migrations` WRITE;
/*!40000 ALTER TABLE `omeka_schema_migrations` DISABLE KEYS */;
INSERT INTO `omeka_schema_migrations` VALUES ('20100401000000'),('20100810120000'),('20110113000000'),('20110124000001'),('20110301103900'),('20110328192100'),('20110426181300'),('20110601112200'),('20110627223000'),('20110824110000'),('20120112100000'),('20120220000000'),('20120221000000'),('20120224000000'),('20120224000001'),('20120402000000'),('20120516000000'),('20120612112000'),('20120623095000'),('20120710000000'),('20120723000000'),('20120808000000'),('20120808000001'),('20120813000000'),('20120914000000'),('20121007000000'),('20121015000000'),('20121015000001'),('20121018000001'),('20121110000000'),('20121218000000'),('20130422000000'),('20130426000000'),('20130429000000'),('20130701000000'),('20130809000000'),('20140304131700'),('20150211000000'),('20150310141100'),('20150814155100'),('20151118214800'),('20151209103300');
/*!40000 ALTER TABLE `omeka_schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_search_texts`
--

DROP TABLE IF EXISTS `omeka_search_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_search_texts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `record_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `record_id` int(10) unsigned NOT NULL,
  `public` tinyint(1) NOT NULL,
  `title` mediumtext COLLATE utf8_unicode_ci,
  `text` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `record_name` (`record_type`,`record_id`),
  FULLTEXT KEY `text` (`text`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_search_texts`
--

LOCK TABLES `omeka_search_texts` WRITE;
/*!40000 ALTER TABLE `omeka_search_texts` DISABLE KEYS */;
INSERT INTO `omeka_search_texts` VALUES (1,'Collection',1,0,'Jewish Perspective on the Boxer Rebellion','Jewish Perspective on the Boxer Rebellion Journal entries from a Jewish soldier during the Boxer Rebellion with modern media of the locations metioned '),(2,'Item',1,1,'Zhmerinka','Zhmerinka 1899-07-07 \"We worked all day carrying the army gear, which was needed for the journey, to the railroad depot. At 11 A.M. we ate our meal and before we could even finish eating the bugle sounded assembly. We threw down the mess kits with the kasha (5) and the borscht and ran to put on full battle gear, and then we fell into formation. We looked at our barracks, which appeared now, empty and deserted. A feeling of terror came upon us.\r\n\r\nMany people were gathered in the parade grounds. Jews, Christians. Civilians and military people - all came to say good-bye and to observe the departure ceremony.\r\n\r\nThen came the regiment commander with the brigade General Katrievitch. The general greeted us first, then came the military chaplain. He conducted a prayer service: he offered a prayer for the welfare of the Czar and his heir and then wished us success and good luck on our journey.\r\n\r\nThe rabbi came to see us, the Jewish soldiers. He brought with him a scroll of the Torah (6) and asked the general if he could conduct a service for us. Permission was granted. The rabbi stood near a table, put on a talis (7) and recited a few psalms. (honoten y\'shuo. a mi sheberach) and that was the end our service. Then Schwartzman, the contractor, brought wine and said he wanted to drink to the general\'s health. And the general gave permission.\r\n\r\nFour silver goblets were brought and filled with wine. The first goblet was given to the general. The second - to our regiment commander. The third - to the commander of the 10th regiment and the fourth - to Schwartsman. The general drank to the health of His Imperial Majesty, the Czar and to the health of Her Imperial Majesty, the Czarina; then he drank to the health of the inhabitants of the town of Zhmerinke, which he said gave him so much joy. We yelled: \"\"Hurrah! Hurrah!” the band played and they all drank the first toast. Then Schwartzman drank to the health of their Excellences. The commanders of the 9th and the 10th regiments and to the health of all the riflemen and we yelled: \"\"Hurrah! Hurrah\"\"\'\r\n\r\nThen vodka was set up for the soldiers and a table of cold cuts for the whole regiment- and it made no difference whether Jew or Christian: all drank. The general was pleased with the local Jews and he thanked them for their help.\r\n\r\nA photographer came and took a picture of the whole regiment so that we would have a reminder of this day. Then Schwartzman said to us: “Even though we are Jews, we are Russian subjects and we should exert every effort to fight the enemy and fight with all we\'ve got. May God give you strength and endurance to overcome everything and to succeed wherever you go.”\r\n\r\nThe band was still playing but things quieted down a little. More vodka was brought in and we drank some more and from regular drinking glasses - we were having a good time in the midst of all our troubles.\r\n\r\nThen all this ended - the regimental commander shouted: \"\"Shoulder arms! Forward march! \"\"The band played a lively, brisk march and we started marching. \r\n\r\nThe officers Started saying good-bye to their wives and children. They kissed and cried and were off to the railroad station singing Russian songs as we marched.\r\n\r\nThe whole town was following us - it felt like a funeral of the living: one was laughing, one was crying and another was sighing as he was looking at these young men going off to war.\r\n\r\nAs we arrived at the railroad station - it was packed full of people. Parents, brothers, sisters and friends were wailing - all wanted to say good-bye and to wish us a pleasant journey. The screaming and the hollering is loud enough to reach   the heavens.	 Just then we heard the first bell. The officers were shouting \"\"into the (train) cars!\"\" The good-byes were said, the tears were pouring and the reminders were heard: “For God\'s sake, don\'t forget to write letters!” We got into the cars - twenty soldiers to a car and as we sat down in our seats we heard the second and third bells.\r\n\r\nThe band was playing a march and all the people were waving good- bye with their hats or with their kerchiefs. The photographer took another picture.  The engineer blew the whistle and the train started moving.  Feeling sad and brokenhearted the soldiers began singing Russian songs. The singing was worse (sadder) than the crying. Some people were still waving good- bye but the train started moving and it was difficult to see now.  We could still hear shouts of “Farewell! Farewell!\"\" Some soldiers were crying and the tears were flowing like water when they heard the shouts of farewell and each one thought to himself: \"\"Who knows whether we will ever see each other again, whether we will ever return and see Zhmerinke.\"\"\r\n\r\nWe soldiers were sitting in our train cars like chickens before the slaughter. We were in a gloomy mood like after N’ilah (9) and all kinds of thoughts ran through our minds: we are going to war we will have to shoot to stab to suffer hardships by the pound - and you begin to rue the day of your birth.\r\n\r\nAs the train started to move, some soldiers were walking around and yelling: \"\"Come. Brothers let\'s drink some vodka and have a bite to eat because if you’ll start brooding you’ll go crazy!\"\" Some men were convinced of this truth and they had so much to drink that they didn\'t know any more what trouble they were in.\r\n\r\nOne soldier got the idea to play cards. So he gathered together a company of men and they played cards. Each one thought that he will win - but one can lose much easier than one can win. Some of the men lost so badly that they were left without a penny - and if one of them ended up owing you money, there was nothing you could do about it unless you were prepared to kill him.\" '),(3,'Item',2,1,'Vinitse','Vinitse 1899-07-07 \"Meanwhile, the train stopped at the railroad station at Vinitse. We were received nicely. The local band was playing and the sign was given to get out of the train cars and then we just stood around for twenty minutes. Many people came running, Jews and Gentiles, and everybody was asking: \"\"Where are you going?\"\" We told everybody in secret: \"\"We are off to war.\"\" One person sighed upon hearing this. Another groaned, a third rolled his eyes and got weepy. We were already sick and tired of the public\'s reaction to our going to war. The first bell rang, the signal was given to get back into the train cars, our \"\"horse\"\" gave a whistle and the train was moving off. All the people were bowing to us taking off their hats and we were yelling: \"\"Hurrah! Hurrah!\"\" The shouting almost broke the train car apart.\r\n\r\nNow night was falling. We started looking around for a place to sleep. But woe! There was nothing to sleep on but the slatted coach seats and even these would not accommodate everybody. Just imagine! Twenty men to a car and there was nothing to put under you for bedding. What was a soldier to do? He had a soldier\'s coat, a \"\"shinel\"\" (10) - that\'s all. As he lay down to sleep the soldier put his shinel under him. And he also covered himself with his shinel and put it under his head as well. So, it would seem that the soldier slept well! When we got up in the morning there was not a bone in our bodies that didn\'t ache because of these \"\"soft\"\" beds that we were sleeping in. When we considered how long we will have to keep on rolling around on these \"\"soft\"\" beds and continue going through all kinds of hardships - it made us feel even worse.\" '),(4,'Item',3,1,'Kursk','Kursk 1899-07-09 \"At 10 o\'clock at night we arrived in KURSK. Kursk is a very big city. The train was delayed and we just waited for two hours. As we got out of our train cars a group of soldiers came up to us. We asked them whether there was any news. They said that everything was quiet around here and they hadn\'t heard any news.\r\n\r\nWe were given permission to go into the city. Kursk is a very big city but very few Jews were to be found here.\r\n\r\nAs we got into the city in the dark of night, a whole bright world opened up before us. We went shopping for food and we did really well: we bought rolls, bread, sugar tea, salami, cigarette paper and things like that which a soldier needs. However. One soldier paid for his purchase and five did not. The merchants made a profit anyway. They knew that we were going to war and they probably figured:\"\" Let them go!\"\" They also knew that we were the first brigades coming and they will do a lot more business.\r\n\r\nAt 10 o\'clock at night we left Kursk . A big crowd came to see us off at the railroad station and everybody was curious to find out where we were going. The band played as we got into our train cars. The third bell rang, the locomotive gave a whistle and we were moving away. The people were bowing to us and we were singing songs and shouting: \"\"Hurrah! Hurrah!\"\"\r\n\r\nAn unusual think happened as we were leaving Kursk. Several soldiers were left behind because they got drunk - dead drunk - and we didn\'t know where to find them.\" '),(5,'Item',4,1,'Penza','Penza 1899-07-14 \"On July 14th we arrived in a big city called PENDZE. A lot of people gathered around when we arrived. We went to eat dinner.\r\n\r\nIn the midst of all this. an old man, holding an alms box, came up to me and offered to pray in church for my successful return if I would put five kopecks in his alms box. My reply to him was: \"\"You came with nothing - you\'ll leave with nothing. And I thought to myself: \"\"Why don\'t you give me five kopecks and then I will pray for you- which you leave me alone and get lost.\"\" We didn\'t think much of this alms-giving business.\r\n\r\nMeanwhile, a train arrived (from the opposite direction) carrying Russian settlers who had to flee for their lives. These people were civilian settlers who lived near Manchuria.\r\n\r\nWhen the war started the Chinese attacked them robbed them and burned their homes. They had to run for their lives and now they were returning to Russia. They were poor and looked threadbare and it was a pity to look at them. They were traveling at government expense just like soldiers: fifty people in one freight car, including women and children. They were receiving (from the government) half a pound of meat and a pound of bread for a mere three kopecks and borscht and tea for free.\" '),(6,'Item',5,1,'Konsk','Konsk 1899-07-25 \"On July 25th we arrived in KONTSK. As I was eating dinner I met two Jews from Warsaw who spent five years of exile here for a fraudulent deal. Their five years of exile were over and since they were about to return to Warsaw I gave them a letter to pass on to my family.\" '),(7,'Item',6,1,'Stretensk','Stretensk 1899-08-10 \"On August 10th we arrived at Stretensk in the CHABAROVSK region. This is where the Siberian railroad ended.\r\n\r\nUntil now we were in pretty good spirits. We traveled on dry land and with the shouts of \"\"Hurrah! Hurrah!\"\" and the singing of songs we traveled across European Russia and much of Siberia. Now begins Asia. It reeks already of China and Manchuria.\r\n\r\nStretensk is a harbor and a Cossack dty. Here live mainly Cossacks. You can find Jews too but very few in number.\r\n\r\nWe got off the train and took all our belongings out of the train car and all the regimental baggage as well. We said good-bye to the train cars that carried us such a long way.\r\n\r\nWe remained at Stretinsk harbor for half a day. We needed to continue our journey by railroad but the Chinese damaged the railroad tracks so that the Russians wouldn\'t be able to bring any reinforcements to the battle area. For that reason we had to stay here. We sent a telegram asking for instructions on how we should proceed and what we should do. We were instructed to continue our journey on water. The waterway here was the river Shilka (or Shilke).\" '),(8,'Item',7,1,'Amur','Amur 1899-08-13 \"On August 13th our ship entered the Amur River. One side of the river belongs to the\r\nChinese - the other to the Russians.\r\n\r\nNow when we stop over to sleep and to cook our dinner we are each issued fifty rounds of ammunition. They also appointed guard posts all around the area to prevent an unexpected attack on us.\r\n\r\nAs we traveled along the river we saw Chinese villages - they had all been burned and destroyed and you didn\'t see a living soul; all that was left were the wooden chimneys of their homes.	We saw fields which had been sown with all kinds of good things and also vineyards which the Chinese left behind as they fled when the battle began.\r\n\r\nA couple of nights we stopped over near forests where wild animals were roaming and snakes could be found as well.	Here we couldn\'t sleep anymore because we were afraid for our \"\"behinds.\"\" We were already sick and tired of this traveling and all the \"\"conveniences\"\" which we enjoy - the eating and the sleeping which we can\'t enjoy neither by day nor by night.	But - we have to put up with it.\" '),(9,'Item',8,1,'San Dzian','San Dzian 1899-09-26 \"We entered the town - it was deserted, not even a dog was to be seen. When the Chinese heard that soldiers were coming they fled with their wives and children and left all their property unattended.\r\n\r\nThe elder of the town remained and he showed us the fort where Chinese soldiers had been stationed but they fled.\r\n\r\nWe entered the fort. We have to settle down here so we immediately started working like horses. Everything needed fixing. Chinese houses have no window panes and no ovens.  They have empty rooms and holes in the walls and here winter is coming. We started fixing things up. We need a kitchen to cook food and an oven to bake bread and quarters with window panes. However, there are no window panes to be had. That is not the Chinese style.         We had to make windows their style that is paper smeared with oil.  We worked eight hours a day. Everything was fixed up in the best way possible. Even dogs may stay here now not just soldiers. Anyway, it is nice and warm except that you can choke from the smoke. First of all they told us to bring in all the things we would need.        We bought flour and we had our provisions brought in and we were all settled in here.\r\n\r\nThen our \"\"boss\"\" arrived, the brigade general Kotnievitch. We all jumped in parade formation and he reviewed each of us carefully and said: \"\"see to it that you fix yourself up because you look poorly. We will spend the winter here and then we will go back to Russia, to our old place.\"\"        We were very happy to hear this news - it really refreshed each one of us.\r\n\r\nThe 17th of December we looked up and here was our exchange unit. We got dressed and moved out on foot to Fen Dziah. As we were marching we thanked God that we survived the first round of Hell.\" '),(10,'Item',9,1,'Niklosk','Niklosk 1900-01-07 \"On Jan. 7 we arrived in Nikolsk. We disembarked from the train and a new world greeted us. We can now see white faces for up to now we have only seen the dark­ skinned Chinese. Many of us lifted our hands to the Living God that He helped us in our needs and troubles without end and protected us from all evil. And we prayed for continued help that we should not have to face again the evil, dark-as-the-devil Chinese with their long braids.\r\n\r\nWe arrive at the railroad station in Nikolsk as the music is playing. We disembark from the train. We were happy to be finished with Manchuria where we could have gotten killed.  We were delighted to see a Russian city again in front of us.  Then as we look around we see people dark faced as the    Chinese.	They are dressed from head to toe in white and are wearing fedora style hats. At first we thought that they were ghosts, but ghosts don\'t wear fedoras. We asked around what kind of animal this was and we were told that these were Koreans.\r\n\r\nNikolsk is a large Russian city.   Here you find people of various nationalities. Russians, Poles, Chinese and Koreans.  You  even  find  a couple  of  Jews  here and the  dark-faced  Japanese  who  are  all  dressed  in  European  clothes.\" '),(11,'Item',10,1,'Vladivostok','Vladivostok 1900-03-05 \"Vladivostock is an important sea-port and many large ships are waiting here to loaded or unloaded.\r\n\r\nAs we got off the train we were all very happy that we were about to leave for Russia. We stacked up our rifles and busied ourselves removing our gear from the baggage cars. We were taking home several flags as well as a few Chinese artillery pieces, rifles, swords and a small Chinese boy. These things were to serve as our remembrances of China.\r\n\r\nEverything was taken out of the train, laid down on the ground and then was loaded onto the ship.\r\nA Chinese baron was traveling with us. We were also carrying a load of long Chinese pipes.\r\n\r\nWhen everything was loaded we went to the baths. After a good wash we boarded the boat. So ended the march in Manchuria. We thanked God that we overcame everything thus far and so far from home - and now we have arrived at this point.\" '),(12,'Item',11,1,'Nagasaki','Nagasaki 1901-03-09 \"After sailing for three days we arrive at an island in the Sea of Japan. On the 9th of March at 5:00 in the afternoon, we enter the port city of Nagasaki. After the ship has docked at the pier a Japanese inspection crew boards us. They are to inspect both cargo and passengers.	As it turns out, it\'s a mere formality and they depart as soon as they arrived. There are ships from many countries anchored at the Port of Nagasaki; we see flags from various nations - American. English. French and Japanese.\r\n\r\nSuddenly, a flotilla of small boats approaches our vessel. They are packed full of goods for sale; we can buy anything imaginable. All kinds of food stuff, baked goods, citrus fruit, cigarettes and soft drinks. They also have gold and silver jewelry. The desire to purchase something is very strong but most of us have little or no money, so we have to satisfy ourselves with just enjoying the sight. Some passengers got into a fist fight with the vendors after not being able to pay for their purchase.	One person got beat up to serve as an example for others, not to take merchandise   for which he was not able to pay. The cheapest of all goods was tea 25 to 30 kopeks a pound where as in Russia, it would cost 2 or even 3 Rubles,\r\n\r\nEach day for three days, the little boats kept coming and the bartering went on. Everything that one\'s heart desired was for sale. Clothing especially, was very inexpensive. Things such as shirts, pants, socks, etc.\r\n\r\nFinally, our boat loads up with fuel (coal), water, food and other supplies and on March 12th, in the morning, we leave Nagasaki. Our destination - Singapore.\r\n\r\nSoon we notice a drastic change in the weather. It\'s getting very hot and we feel the heat increasing as the day progresses. We receive orders to don our white outfits – pants, shirts and white cap. These are supposed to protect us from the sun and heat and were especially made for us in Nikolsk. When we look at ourselves and each other, we can\'t help but laugh, because we look like the walking dead!\r\n\r\nWe sail on and see nothing but endless seas, blue sky and a hot sun. Occasionally, we pass another boat or small island, and then again, the same monotony.\r\n\r\nThe heat becomes almost unbearable.	Our new clothing is getting wet and heavy, as we sweat profusely. Had it not been for our sense of feeling ashamed, we would have walked about naked!\r\n\r\nOur boat begins to rock back and forth and from side to side. A motion disagreeable to most of us and we begin another bout with sea sickness.  We are trying to stay on deck since sea sickness below deck is an even worse experience. But there is little or no room for everybody, and it\'s impossible to find a shady spot to be protected from the punishing sun rays.\r\n\r\nEvery other day is laundry day. We have to do it ourselves and the only water we can use is salt water.	We find the salt water needs more soap to make suds and that presents a problem, as well. We have to do the best we can under the circumstances and hopefully our soap supply will outlast our dirt.\" '),(13,'Item',12,1,'Samar','Samar 1899-07-15 \"At noon we arrived in Samar - also a very big day.  We had our meal near the railroad station and then each one of us received two glasses of beer.  We didn\'t know where this beer came from or who had donated it, Later we learned that there was a wealthy brewer here in Samar and that he treated the entire brigade to free beer because we were going to war. That was very nice and I wouldn\'t have minded having some beer every day - and some food as well.\r\n\r\nAfter we had the beer we went into the city. The city of Samar is very big but very few Jews could be found here. Those who lived here were all tradesmen who received residence-permits because deep inside Russia (outside the pale of settlement) Jews were not allowed to live unless they received special permission. And when you met one of these Jews, you would never recognize that it was a Jew because they had become thoroughly crucified, spoke only Russian and knew very little of their Jewish heritage.\r\n\r\nWe left Samar as the band was playing merrily\r\n.\" '),(14,'SimplePagesPage',1,1,'About','About <p>This is an example page. Feel free to replace this content, or delete the page and start from scratch.</p> '),(15,'SimplePagesPage',2,1,'Help Us Uncover More Accurate Data','Help Us Uncover More Accurate Data <h3>Do you have historic photographs of this location?</h3>\r\n[items ids=3]\r\nIf so, please <a href=\"mailto:null\">share them with us</a>! \r\n<hr>\r\n<h3>Do you know a more precise location for this entry?</h3>\r\n[items ids=7]\r\nIf so please <a href=\"http://localhost/omeka/corrections/index/add/item_id/7\">suggest a correction</a> '),(16,'Comment',1,1,'Test comment','<p>Test comment</p> ');
/*!40000 ALTER TABLE `omeka_search_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_sessions`
--

DROP TABLE IF EXISTS `omeka_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_sessions` (
  `id` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `modified` bigint(20) DEFAULT NULL,
  `lifetime` int(11) DEFAULT NULL,
  `data` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_sessions`
--

LOCK TABLES `omeka_sessions` WRITE;
/*!40000 ALTER TABLE `omeka_sessions` DISABLE KEYS */;
INSERT INTO `omeka_sessions` VALUES ('290ot64cdqvmfkrrkdkfka8dk0',1466435819,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('2mofrnu07udja6rah44anhieb6',1466456422,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"71fc4421af33a90b38fc527fe62689a2\";}'),('3lqpgdfum1loilic69irnnmvd0',1465940242,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"6563b0584769f2f51fc9000f96e7fbed\";}'),('64164dv2qo8892stnp7r9jro31',1466446580,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"0c18953ceba9e4203f3c32d941599044\";}'),('6a378jsusl1auchk1es1ai79q3',1466201221,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"3e014aa758bacbdd0ff81d72512e0e84\";}'),('7b8ps7s9ho7lh78kifqc6k16j4',1465929744,1209600,''),('8dg1cp3j5f59snt5lul55apii1',1470240702,1209600,''),('9ev6u8ic72ouf5lpbli6piipl4',1465920116,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"9a1e3aaaf90328a7e1a6e12e529310a1\";}__ZF|a:1:{s:43:\"Zend_Form_Element_Hash_salt_navigation_csrf\";a:2:{s:4:\"ENNH\";i:1;s:3:\"ENT\";i:1465923255;}}Zend_Form_Element_Hash_salt_navigation_csrf|a:1:{s:4:\"hash\";s:32:\"651e1b8da08e5d43ab3ff3d41ec5bf9b\";}'),('bmu97hderjl3nrtaajca8rmp91',1466433567,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}'),('hlok5pu8b04ftcv9b0t81p3017',1466197170,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"b7ef90d7d44efbda2102fcb40b094323\";}'),('ib9713369fnm7or0m0ivnov8k3',1466195122,1209600,''),('lb86d07tpk12qvdanh4ohjhd46',1466435819,1209600,''),('lhdtsa6jdk5fdpgrg930fajso7',1466186861,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}OmekaSessionCsrfToken|a:1:{s:5:\"token\";s:32:\"6519e3de56d3a1b297452ddcfece1562\";}'),('lhk368n35i41d9qmp07tjv55q5',1466456928,1209600,'Default|a:1:{s:8:\"redirect\";s:1:\"/\";}Zend_Auth|a:1:{s:7:\"storage\";i:1;}'),('mug7d27j4s1u0a5bofutk1oma6',1466191515,1209600,''),('nb9b01iumll6crn1h1u4k8gm04',1466199081,1209600,''),('pq36gnm76lbn8743dpuvoubhe6',1466194975,1209600,''),('q9s39p2eilbs1aot9thi17jpq1',1466195069,1209600,'');
/*!40000 ALTER TABLE `omeka_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_simple_pages_pages`
--

DROP TABLE IF EXISTS `omeka_simple_pages_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_simple_pages_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modified_by_user_id` int(10) unsigned NOT NULL,
  `created_by_user_id` int(10) unsigned NOT NULL,
  `is_published` tinyint(1) NOT NULL,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `slug` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `text` mediumtext COLLATE utf8_unicode_ci,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `inserted` timestamp NOT NULL DEFAULT '2000-01-01 05:00:00',
  `order` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `template` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `use_tiny_mce` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `is_published` (`is_published`),
  KEY `inserted` (`inserted`),
  KEY `updated` (`updated`),
  KEY `created_by_user_id` (`created_by_user_id`),
  KEY `modified_by_user_id` (`modified_by_user_id`),
  KEY `order` (`order`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_simple_pages_pages`
--

LOCK TABLES `omeka_simple_pages_pages` WRITE;
/*!40000 ALTER TABLE `omeka_simple_pages_pages` DISABLE KEYS */;
INSERT INTO `omeka_simple_pages_pages` VALUES (1,1,1,1,'About','about','<p>This is an example page. Feel free to replace this content, or delete the page and start from scratch.</p>','2016-06-22 13:12:28','2016-06-22 13:12:28',0,0,'',0),(2,1,1,1,'Help Us Uncover More Accurate Data','mysteries','<h3>Do you have historic photographs of this location?</h3>\r\n[items ids=3]\r\nIf so, please <a href=\"mailto:null\">share them with us</a>! \r\n<hr>\r\n<h3>Do you know a more precise location for this entry?</h3>\r\n[items ids=7]\r\nIf so please <a href=\"http://localhost/omeka/corrections/index/add/item_id/7\">suggest a correction</a>','2016-06-22 14:12:32','2016-06-22 14:09:45',0,0,'',0);
/*!40000 ALTER TABLE `omeka_simple_pages_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_tags`
--

DROP TABLE IF EXISTS `omeka_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_tags`
--

LOCK TABLES `omeka_tags` WRITE;
/*!40000 ALTER TABLE `omeka_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_users`
--

DROP TABLE IF EXISTS `omeka_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salt` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `role` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `active_idx` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_users`
--

LOCK TABLES `omeka_users` WRITE;
/*!40000 ALTER TABLE `omeka_users` DISABLE KEYS */;
INSERT INTO `omeka_users` VALUES (1,'magicproto','Super User','cs4dh@faokryn.com','5c5fe401901d2dd1bdefa75ea554ad6a53654c1d','a44284651271248f',1,'super');
/*!40000 ALTER TABLE `omeka_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `omeka_users_activations`
--

DROP TABLE IF EXISTS `omeka_users_activations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `omeka_users_activations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `omeka_users_activations`
--

LOCK TABLES `omeka_users_activations` WRITE;
/*!40000 ALTER TABLE `omeka_users_activations` DISABLE KEYS */;
/*!40000 ALTER TABLE `omeka_users_activations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-08-08 16:40:16
